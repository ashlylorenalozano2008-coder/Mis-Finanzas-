const form = document.getElementById("formulario");
const lista = document.getElementById("lista");
const ingresosEl = document.getElementById("ingresos");
const gastosEl = document.getElementById("gastos");
const balanceEl = document.getElementById("balance");
const fraseFooter = document.getElementById("fraseFooter");
const fraseResumen = document.getElementById("fraseResumen");
const inputMonto = document.getElementById("monto");

let ingresos = 0;
let gastos = 0;

const formatoCOP = new Intl.NumberFormat("es-CO", {
  style: "currency",
  currency: "COP",
  minimumFractionDigits: 0
});

const frasesFooter = [
  "Cada peso cuenta: cuida tu dinero, cuida tu futuro.",
  "Ahorra hoy para disfrutar mañana.",
  "El dinero bien cuidado es tranquilidad asegurada.",
  "Save today, shine tomorrow ✨",
  "Controla tus gastos y controlarás tus sueños 💖"
];

const frasesResumen = [
  "¡Vas muy bien!",
  "Sigue cuidando tu dinero ✨",
  "Pequeños ahorros hacen grandes logros ⭐",
  "Cada decisión cuenta 🌸",
  "Disciplina hoy, libertad mañana 💎"
];

function mostrarFrases() {
  fraseFooter.textContent = frasesFooter[Math.floor(Math.random() * frasesFooter.length)];
  fraseResumen.textContent = frasesResumen[Math.floor(Math.random() * frasesResumen.length)];
}

mostrarFrases();
setInterval(mostrarFrases, 10000);

// Formatear input en tiempo real
inputMonto.addEventListener("input", () => {
  let valor = inputMonto.value.replace(/[^0-9]/g, ""); // solo números
  if (valor) {
    inputMonto.value = formatoCOP.format(valor);
  } else {
    inputMonto.value = "";
  }
});

form.addEventListener("submit", function(e){
  e.preventDefault();

  const desc = document.getElementById("descripcion").value;
  let monto = parseFloat(inputMonto.value.replace(/[^0-9]/g, ""));
  const tipo = document.getElementById("tipo").value;

  if(isNaN(monto) || monto <= 0){
    alert("Por favor escribe un monto válido");
    return;
  }

  const div = document.createElement("div");
  div.classList.add("movimiento", tipo);
  div.innerHTML = `<span>${desc}</span><span>${formatoCOP.format(monto)}</span>`;
  lista.appendChild(div);

  if(tipo === "ingreso"){
    ingresos += monto;
  } else {
    gastos += monto;
  }

  const balance = ingresos - gastos;

  ingresosEl.textContent = formatoCOP.format(ingresos);
  gastosEl.textContent = formatoCOP.format(gastos);
  balanceEl.textContent = formatoCOP.format(balance);

  form.reset();
});